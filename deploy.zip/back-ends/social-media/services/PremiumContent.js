class PremiumContent{
    constructor(content){
        this.content = content;
    }
}

module.exports = PremiumContent;