class PersonalData{

    constructor(username, location, DOB, business, picture){
        this.name=username;
        this.location = location;
        this.DOB = DOB;
        this.business = business;
        this.picture = picture;
    }
}
module.exports = PersonalData;